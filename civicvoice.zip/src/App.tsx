/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  collection, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  doc, 
  setDoc, 
  deleteDoc, 
  query, 
  orderBy, 
  increment, 
  getDoc,
  getDocFromServer,
  runTransaction
} from 'firebase/firestore';
import { 
  signInWithPopup, 
  GoogleAuthProvider, 
  onAuthStateChanged, 
  signOut,
  User as FirebaseUser 
} from 'firebase/auth';
import { auth, db } from './firebase';
import { Issue, IssueStatus, IssueCategory, User, Vote } from './types';
import { cn } from './lib/utils';
import { 
  Plus, 
  ThumbsUp, 
  MessageSquare, 
  AlertCircle, 
  CheckCircle2, 
  Clock, 
  Filter, 
  LogOut, 
  User as UserIcon,
  ChevronDown,
  MapPin,
  Search,
  ArrowUp,
  MoreVertical,
  Trash2,
  ShieldCheck
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { formatDistanceToNow } from 'date-fns';

// Error handling as per instructions
enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

const CATEGORIES: IssueCategory[] = ['Infrastructure', 'Environment', 'Safety', 'Health', 'Other'];
const STATUSES: IssueStatus[] = ['open', 'in-progress', 'resolved'];

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [issues, setIssues] = useState<Issue[]>([]);
  const [userVotes, setUserVotes] = useState<Record<string, boolean>>({});
  const [loading, setLoading] = useState(true);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [filter, setFilter] = useState<IssueStatus | 'all'>('all');
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<IssueCategory | 'all'>('all');

  // Test connection as per instructions
  useEffect(() => {
    async function testConnection() {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if(error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration. ");
        }
      }
    }
    testConnection();
  }, []);

  // Auth listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        const userDocRef = doc(db, 'users', firebaseUser.uid);
        try {
          const userDoc = await getDoc(userDocRef);
          if (userDoc.exists()) {
            setUser(userDoc.data() as User);
          } else {
            // Create user profile
            const newUser: User = {
              uid: firebaseUser.uid,
              displayName: firebaseUser.displayName || 'Anonymous',
              photoURL: firebaseUser.photoURL || undefined,
              role: firebaseUser.email === 'yashbochare21@gmail.com' ? 'admin' : 'user',
              createdAt: new Date().toISOString()
            };
            await setDoc(userDocRef, newUser);
            setUser(newUser);
          }
        } catch (error) {
          console.error('Error fetching/creating user doc:', error);
        }
      } else {
        setUser(null);
      }
      setIsAuthReady(true);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  // Issues listener
  useEffect(() => {
    if (!isAuthReady) return;

    const q = query(collection(db, 'issues'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const issuesData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Issue));
      setIssues(issuesData);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'issues');
    });

    return () => unsubscribe();
  }, [isAuthReady]);

  // User votes listener
  useEffect(() => {
    if (!user) {
      setUserVotes({});
      return;
    }

    const q = query(collection(db, 'votes'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const votes: Record<string, boolean> = {};
      snapshot.docs.forEach(doc => {
        const vote = doc.data() as Vote;
        if (vote.userId === user.uid) {
          votes[vote.issueId] = true;
        }
      });
      setUserVotes(votes);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'votes');
    });

    return () => unsubscribe();
  }, [user]);

  const handleLogin = async () => {
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error('Login error:', error);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  const handleVote = async (issueId: string) => {
    if (!user) return;

    const voteId = `${user.uid}_${issueId}`;
    const voteRef = doc(db, 'votes', voteId);
    const issueRef = doc(db, 'issues', issueId);

    try {
      await runTransaction(db, async (transaction) => {
        const voteDoc = await transaction.get(voteRef);
        const issueDoc = await transaction.get(issueRef);

        if (!issueDoc.exists()) throw new Error('Issue does not exist');

        if (voteDoc.exists()) {
          // Remove vote
          transaction.delete(voteRef);
          transaction.update(issueRef, { voteCount: increment(-1) });
        } else {
          // Add vote
          transaction.set(voteRef, {
            userId: user.uid,
            issueId,
            createdAt: new Date().toISOString()
          });
          transaction.update(issueRef, { voteCount: increment(1) });
        }
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `votes/${voteId}`);
    }
  };

  const filteredIssues = useMemo(() => {
    return issues.filter(issue => {
      const matchesStatus = filter === 'all' || issue.status === filter;
      const matchesCategory = categoryFilter === 'all' || issue.category === categoryFilter;
      const matchesSearch = issue.title.toLowerCase().includes(search.toLowerCase()) || 
                           issue.description.toLowerCase().includes(search.toLowerCase());
      return matchesStatus && matchesCategory && matchesSearch;
    });
  }, [issues, filter, categoryFilter, search]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] flex items-center justify-center">
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-12 h-12 border-4 border-[#5A5A40] border-t-transparent rounded-full"
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F5F0] text-[#1a1a1a] font-serif">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-[#5A5A40]/10 px-6 py-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-[#5A5A40] rounded-full flex items-center justify-center text-white">
              <ShieldCheck size={24} />
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-[#5A5A40]">CivicVoice</h1>
          </div>

          <div className="flex items-center gap-4">
            {user ? (
              <div className="flex items-center gap-4">
                <div className="hidden md:flex items-center gap-2 bg-white px-3 py-1.5 rounded-full border border-[#5A5A40]/20">
                  {user.photoURL ? (
                    <img src={user.photoURL} alt={user.displayName} className="w-6 h-6 rounded-full" referrerPolicy="no-referrer" />
                  ) : (
                    <UserIcon size={16} className="text-[#5A5A40]" />
                  )}
                  <span className="text-sm font-medium">{user.displayName}</span>
                  {user.role === 'admin' && (
                    <span className="text-[10px] uppercase tracking-wider bg-[#5A5A40] text-white px-1.5 py-0.5 rounded-sm font-sans">Admin</span>
                  )}
                </div>
                <button 
                  onClick={handleLogout}
                  className="p-2 hover:bg-red-50 text-red-600 rounded-full transition-colors"
                  title="Logout"
                >
                  <LogOut size={20} />
                </button>
              </div>
            ) : (
              <button 
                onClick={handleLogin}
                className="bg-[#5A5A40] text-white px-6 py-2 rounded-full font-medium hover:bg-[#4A4A30] transition-all shadow-sm"
              >
                Sign In
              </button>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-8">
        {/* Hero Section */}
        <div className="mb-12 text-center">
          <h2 className="text-5xl font-bold mb-4 leading-tight">Your Voice, Your Community.</h2>
          <p className="text-xl text-[#5A5A40]/70 max-w-2xl mx-auto italic">
            Report local issues, vote on solutions, and track real-time progress in your neighborhood.
          </p>
        </div>

        {/* Controls */}
        <div className="flex flex-col md:flex-row gap-4 mb-8 items-center justify-between">
          <div className="flex flex-wrap gap-2 items-center">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[#5A5A40]/40" size={18} />
              <input 
                type="text" 
                placeholder="Search issues..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10 pr-4 py-2 bg-white border border-[#5A5A40]/20 rounded-full focus:outline-none focus:ring-2 focus:ring-[#5A5A40]/20 w-64 font-sans text-sm"
              />
            </div>
            
            <div className="flex bg-white p-1 rounded-full border border-[#5A5A40]/20">
              {['all', ...STATUSES].map((s) => (
                <button
                  key={s}
                  onClick={() => setFilter(s as any)}
                  className={cn(
                    "px-4 py-1.5 rounded-full text-xs font-medium capitalize transition-all",
                    filter === s ? "bg-[#5A5A40] text-white" : "text-[#5A5A40]/60 hover:text-[#5A5A40]"
                  )}
                >
                  {s}
                </button>
              ))}
            </div>

            <select 
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value as any)}
              className="bg-white border border-[#5A5A40]/20 rounded-full px-4 py-2 text-sm focus:outline-none font-sans"
            >
              <option value="all">All Categories</option>
              {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>

          {user && (
            <button 
              onClick={() => setShowForm(true)}
              className="flex items-center gap-2 bg-[#5A5A40] text-white px-6 py-2.5 rounded-full font-medium hover:bg-[#4A4A30] transition-all shadow-md active:scale-95"
            >
              <Plus size={20} />
              Report Issue
            </button>
          )}
        </div>

        {/* Issue List */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <AnimatePresence mode="popLayout">
            {filteredIssues.map((issue) => (
              <IssueCard 
                key={issue.id} 
                issue={issue} 
                user={user} 
                hasVoted={!!userVotes[issue.id]} 
                onVote={() => handleVote(issue.id)}
              />
            ))}
          </AnimatePresence>
          
          {filteredIssues.length === 0 && (
            <div className="col-span-full py-20 text-center">
              <div className="w-20 h-20 bg-[#5A5A40]/5 rounded-full flex items-center justify-center mx-auto mb-4">
                <AlertCircle size={40} className="text-[#5A5A40]/20" />
              </div>
              <h3 className="text-xl font-medium text-[#5A5A40]/60">No issues found</h3>
              <p className="text-[#5A5A40]/40">Try adjusting your filters or search terms.</p>
            </div>
          )}
        </div>
      </main>

      {/* Issue Form Modal */}
      <AnimatePresence>
        {showForm && (
          <IssueFormModal 
            onClose={() => setShowForm(false)} 
            user={user!} 
          />
        )}
      </AnimatePresence>

      {/* Footer */}
      <footer className="mt-20 border-t border-[#5A5A40]/10 py-12 px-6 bg-white">
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-12">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-[#5A5A40] rounded-full flex items-center justify-center text-white">
                <ShieldCheck size={18} />
              </div>
              <h3 className="text-xl font-bold tracking-tight text-[#5A5A40]">CivicVoice</h3>
            </div>
            <p className="text-[#5A5A40]/60 italic">
              Empowering communities through transparency and collective action.
            </p>
          </div>
          <div>
            <h4 className="font-bold mb-4 uppercase tracking-widest text-xs text-[#5A5A40]/40">Platform</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="hover:text-[#5A5A40] transition-colors">About Us</a></li>
              <li><a href="#" className="hover:text-[#5A5A40] transition-colors">How it Works</a></li>
              <li><a href="#" className="hover:text-[#5A5A40] transition-colors">Community Guidelines</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-4 uppercase tracking-widest text-xs text-[#5A5A40]/40">Legal</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="hover:text-[#5A5A40] transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-[#5A5A40] transition-colors">Terms of Service</a></li>
            </ul>
          </div>
        </div>
        <div className="max-w-6xl mx-auto mt-12 pt-8 border-t border-[#5A5A40]/5 text-center text-xs text-[#5A5A40]/30">
          © {new Date().getFullYear()} CivicVoice. All rights reserved.
        </div>
      </footer>
    </div>
  );
}

function IssueCard({ issue, user, hasVoted, onVote }: { issue: Issue, user: User | null, hasVoted: boolean, onVote: () => void }) {
  const [isUpdating, setIsUpdating] = useState(false);

  const handleStatusChange = async (newStatus: IssueStatus) => {
    if (!user || user.role !== 'admin') return;
    setIsUpdating(true);
    try {
      await updateDoc(doc(db, 'issues', issue.id), { status: newStatus });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `issues/${issue.id}`);
    } finally {
      setIsUpdating(false);
    }
  };

  const handleDelete = async () => {
    if (!user || user.role !== 'admin') return;
    if (!confirm('Are you sure you want to delete this issue?')) return;
    
    try {
      await deleteDoc(doc(db, 'issues', issue.id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `issues/${issue.id}`);
    }
  };

  const statusColors = {
    'open': 'bg-blue-50 text-blue-700 border-blue-200',
    'in-progress': 'bg-amber-50 text-amber-700 border-amber-200',
    'resolved': 'bg-emerald-50 text-emerald-700 border-emerald-200'
  };

  const statusIcons = {
    'open': <AlertCircle size={14} />,
    'in-progress': <Clock size={14} />,
    'resolved': <CheckCircle2 size={14} />
  };

  return (
    <motion.div 
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="bg-white rounded-[2rem] p-6 shadow-sm border border-[#5A5A40]/10 flex flex-col h-full hover:shadow-md transition-all group"
    >
      <div className="flex justify-between items-start mb-4">
        <span className={cn(
          "px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider border flex items-center gap-1.5",
          statusColors[issue.status]
        )}>
          {statusIcons[issue.status]}
          {issue.status}
        </span>
        
        {user?.role === 'admin' && (
          <div className="relative group/menu">
            <button className="p-1.5 hover:bg-[#5A5A40]/5 rounded-full transition-colors">
              <MoreVertical size={18} className="text-[#5A5A40]/40" />
            </button>
            <div className="absolute right-0 top-full mt-1 bg-white border border-[#5A5A40]/10 rounded-xl shadow-xl py-2 w-40 opacity-0 invisible group-hover/menu:opacity-100 group-hover/menu:visible transition-all z-10">
              <div className="px-3 py-1 text-[10px] font-bold uppercase text-[#5A5A40]/40 tracking-widest">Set Status</div>
              {STATUSES.map(s => (
                <button 
                  key={s}
                  onClick={() => handleStatusChange(s)}
                  disabled={isUpdating}
                  className={cn(
                    "w-full text-left px-4 py-2 text-sm hover:bg-[#5A5A40]/5 transition-colors capitalize",
                    issue.status === s ? "text-[#5A5A40] font-bold" : "text-[#5A5A40]/60"
                  )}
                >
                  {s}
                </button>
              ))}
              <div className="my-1 border-t border-[#5A5A40]/5" />
              <button 
                onClick={handleDelete}
                className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors flex items-center gap-2"
              >
                <Trash2 size={14} />
                Delete
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="mb-2 text-[10px] font-bold uppercase tracking-widest text-[#5A5A40]/40 flex items-center gap-2">
        <MapPin size={10} />
        {issue.category}
      </div>

      <h3 className="text-xl font-bold mb-3 line-clamp-2 leading-tight group-hover:text-[#5A5A40] transition-colors">{issue.title}</h3>
      <p className="text-[#5A5A40]/70 text-sm mb-6 line-clamp-3 italic leading-relaxed">"{issue.description}"</p>

      <div className="mt-auto pt-6 border-t border-[#5A5A40]/5 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-[#5A5A40]/5 rounded-full flex items-center justify-center text-[#5A5A40]/40">
            <UserIcon size={16} />
          </div>
          <div className="flex flex-col">
            <span className="text-[10px] font-bold text-[#5A5A40]">{issue.authorName || 'Anonymous'}</span>
            <span className="text-[9px] text-[#5A5A40]/40">{formatDistanceToNow(new Date(issue.createdAt))} ago</span>
          </div>
        </div>

        <button 
          onClick={onVote}
          disabled={!user}
          className={cn(
            "flex items-center gap-2 px-4 py-2 rounded-full transition-all active:scale-90",
            hasVoted 
              ? "bg-[#5A5A40] text-white shadow-md" 
              : "bg-[#5A5A40]/5 text-[#5A5A40] hover:bg-[#5A5A40]/10"
          )}
        >
          <ArrowUp size={16} className={cn(hasVoted && "animate-bounce")} />
          <span className="font-bold text-sm">{issue.voteCount}</span>
        </button>
      </div>
    </motion.div>
  );
}

function IssueFormModal({ onClose, user }: { onClose: () => void, user: User }) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<IssueCategory>('Infrastructure');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !description) return;

    setIsSubmitting(true);
    try {
      const newIssue = {
        title,
        description,
        category,
        status: 'open' as IssueStatus,
        authorId: user.uid,
        authorName: user.displayName,
        createdAt: new Date().toISOString(),
        voteCount: 0
      };
      await addDoc(collection(db, 'issues'), newIssue);
      onClose();
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'issues');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-[#1a1a1a]/40 backdrop-blur-sm"
      />
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9, y: 20 }}
        className="relative bg-white w-full max-w-xl rounded-[2.5rem] shadow-2xl overflow-hidden"
      >
        <div className="p-8 md:p-12">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold text-[#5A5A40]">Report an Issue</h2>
            <button onClick={onClose} className="p-2 hover:bg-[#5A5A40]/5 rounded-full transition-colors">
              <Plus size={24} className="rotate-45 text-[#5A5A40]/40" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-[10px] font-bold uppercase tracking-widest text-[#5A5A40]/40 mb-2">Category</label>
              <div className="flex flex-wrap gap-2">
                {CATEGORIES.map(c => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setCategory(c)}
                    className={cn(
                      "px-4 py-2 rounded-full text-xs font-medium transition-all border",
                      category === c 
                        ? "bg-[#5A5A40] text-white border-[#5A5A40]" 
                        : "bg-white text-[#5A5A40]/60 border-[#5A5A40]/20 hover:border-[#5A5A40]/40"
                    )}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase tracking-widest text-[#5A5A40]/40 mb-2">Title</label>
              <input 
                type="text" 
                required
                minLength={5}
                maxLength={100}
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Briefly describe the issue..."
                className="w-full bg-[#F5F5F0] border-none rounded-2xl px-6 py-4 focus:ring-2 focus:ring-[#5A5A40]/20 outline-none font-sans"
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase tracking-widest text-[#5A5A40]/40 mb-2">Description</label>
              <textarea 
                required
                minLength={10}
                maxLength={2000}
                rows={4}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Provide more details about what's happening..."
                className="w-full bg-[#F5F5F0] border-none rounded-2xl px-6 py-4 focus:ring-2 focus:ring-[#5A5A40]/20 outline-none font-sans resize-none"
              />
            </div>

            <button 
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-[#5A5A40] text-white py-4 rounded-full font-bold text-lg hover:bg-[#4A4A30] transition-all shadow-lg active:scale-[0.98] disabled:opacity-50"
            >
              {isSubmitting ? "Submitting..." : "Submit Report"}
            </button>
          </form>
        </div>
      </motion.div>
    </div>
  );
}
