export type IssueStatus = 'open' | 'in-progress' | 'resolved';
export type IssueCategory = 'Infrastructure' | 'Environment' | 'Safety' | 'Health' | 'Other';

export interface User {
  uid: string;
  displayName: string;
  photoURL?: string;
  role: 'user' | 'admin';
  createdAt?: string;
}

export interface Issue {
  id: string;
  title: string;
  description: string;
  category: IssueCategory;
  status: IssueStatus;
  authorId: string;
  authorName?: string;
  createdAt: string;
  voteCount: number;
}

export interface Vote {
  userId: string;
  issueId: string;
  createdAt: string;
}
